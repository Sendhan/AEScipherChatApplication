# import necessary modules
import os
import socket
import tqdm
from zipfile import ZipFile
import random
from threading import Thread
from datetime import datetime
from colorama import Fore, init, Back


# IMPORT necessary USER defined modules
import FileManager as fm 
import EncryptDecrypt as ED
import CheckSumValidator as CSV


# init colors
init()

# set the available colors
colors = [Fore.BLUE, Fore.CYAN, Fore.GREEN, Fore.LIGHTBLACK_EX, 
	Fore.LIGHTBLUE_EX, Fore.LIGHTCYAN_EX, Fore.LIGHTGREEN_EX, 
	Fore.LIGHTMAGENTA_EX, Fore.LIGHTRED_EX, Fore.LIGHTWHITE_EX, 
	Fore.LIGHTYELLOW_EX, Fore.MAGENTA, Fore.RED, Fore.WHITE, Fore.YELLOW
]

# choose a random color for the client
client_color = random.choice(colors)  


def listen_for_messages():
	while True:
		message = client_socket.recv(1024).decode()
		print("\n" + message)
		
		
def send_file():
	# r = client_socket.recv(8).decode()
	# print("Message from the server : {r}")
	path = input("Enter the path of the files to be sent: ")
	file_name = fm.collectfiles(path)
	with open(file_name, 'rb') as file:
		data = file.read()
	filename = file_name + ".bin"
	ED.encrypt(key, data, filename)	
	# get the name of the file which we want to send to the server
	# filename = file_name input("Enter name of the file to be sent: ")
	# get the file size 
	filesize = os.path.getsize(filename)
	sender_checksum = CSV.getCheckSum(file_name)
	#send the filename and file size to the server
	client_socket.send(f"{filename}{SEPARATOR}{filesize}{SEPARATOR}{sender_checksum}".encode())
	# start sending the file
	progress = tqdm.tqdm(range(filesize), f"Sending {filename}", unit="B", unit_scale=True, unit_divisor=1024)
	with open(filename, 'rb') as file:
		while True:
			# read the bytes from the file
			bytes_read = file.read(BUFFER_SIZE)
			if not bytes_read:
				# file transmitting is done
				break
			# we use sendall to assure transmission in busy networks
			client_socket.sendall(bytes_read)
			# update the progress bar
			progress.update(len(bytes_read))
	os.remove(filename)
	os.remove(file_name)


key = b'\xa2\xe8\xc3?\x0b}\xb6\xd4\xc1ZgN\x9a?zw'


# assigning HOST and PORT Number of the server
HOST = "0.0.0.0"
PORT = 65432


# assign buffer_size as 1024 bits per Second
BUFFER_SIZE = 1024
SEPARATOR = "<SEPARATOR>"
separator_token = "<SEP>" # we will use this to separate the client name & message


# create a TCP client socket 
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
	# connect to the intended server 
	print(f"[+] Connecting to {HOST}:{PORT}")
	client_socket.connect((HOST, PORT))
	print("[+] Connected")
	# prompt the client for a name
	name = input("Enter your name: ")
	# make a thread that listens for messages to this client & print them
	t = Thread(target=listen_for_messages)
	# make the thread daemon so it ends whenever the main thread ends
	t.daemon = True
	# start the thread
	t.start()
	while True:
		# input message we want to send to the server
		to_send =  input("Enter the message you want to send to the server: ")
		# a way to exit the program
		if to_send.lower() == 'quit':
			break
			exit(0)
		elif to_send == "Server receive the file":
			client_socket.send(to_send.encode())
			send_file()
		else:
			# add the datetime, name & the color of the sender
			date_now = datetime.now().strftime('%Y-%m-%d %H:%M:%S') 
			to_send = f"{client_color}[{date_now}] {name}{separator_token}{to_send}{Fore.RESET}"
			# finally, send the message
			client_socket.send(to_send.encode())