# import necessary modules
import os
import socket
import tqdm
import time
from threading import Thread


# importing user defined modules
import ApplicationOpener as AppO
import FileManager as fm
import EncryptDecrypt as ED
import CheckSumValidator as CSV 


key = b'\xa2\xe8\xc3?\x0b}\xb6\xd4\xc1ZgN\x9a?zw'


# finds the Operating System used for the server
platform_num = AppO.find_platform()
default_path = fm.getDefaultDir()
destination_path = fm.MakeNewDirectory(platform_num)


def receive():
	
	received = client_socket.recv(BUFFER_SIZE).decode()
	filename, filesize, sender_checksum = received.split(SEPARATOR)
	print(f"Received: {received}\n, filename: {filename}, filesize: {filesize}, sender_checksum: {sender_checksum}")
	# remove absolute path if there is
	filename = os.path.basename(filename)
	filename = destination_path + r"/" + filename
	print("filename: ",filename)
	# convert the file-size from strings to integer
	filesize = int(filesize)
	# start receiving the file from the client
	progress = tqdm.tqdm(range(filesize), f"Received {filename}", unit="B", unit_scale=True, unit_divisor=1024)
	with open(filename, 'wb') as file:
		while True:
			# read 1024 bytes from the socket (receive)
			bytes_read = client_socket.recv(BUFFER_SIZE)
			if not bytes_read:    
				# nothing is received
				# file transmitting is done
				break
			# write to the file the bytes we just received
			file.write(bytes_read)
			# update the progress bar
			progress.update(len(bytes_read))
	receiver_checksum = fm.receivefile(filename, key)
	print(f"receiver_checksum: {receiver_checksum}")
	Integrity = CSV.checkIntegrity(sender_checksum, receiver_checksum)
	if Integrity != True:
		print("File Transmitted was incorrect o(╥﹏╥)")
	else:
		print("File Trasmission was is successful ᕕ( ᐛ )ᕗ")


def listen_for_client(cs):
	"""
	This function keep listening for a message from `cs` socket
	Whenever a message is received, broadcast it to all other connected clients
	"""
	opt = 0
	while True:
		try:
			# keep listening for a message from `cs` socket
			msg = cs.recv(1024).decode()
			if msg == "quit":
				cs.close()
			if msg == "Server receive the file":
				# cs.send("ok send".encode())
				receive()
				opt = 1
		except Exception as e:
			# client no longer connected
			# remove it from the set
			print(f"[!] Error: {e}")
			client_sockets.remove(cs)
		else:
			# if we received a message, replace the <SEP> 
			# token with ": " for nice printing
			msg = msg.replace(separator_token, ": ")
		# iterate over all connected sockets
		for client_socket in client_sockets:
			# and send the message
			if opt != 1:
				client_socket.send(msg.encode())
		opt = 0	

# assigning HOST and PORT Number
HOST = "0.0.0.0"
PORT = 65432
address = (HOST, PORT)


# assign buffer_size as 1024 bits per Second
BUFFER_SIZE = 1024
SEPARATOR = "<SEPARATOR>"
separator_token = "<SEP>" # we will use this to separate the client name & message


# initialize list/set of all connected client's sockets
client_sockets = set()


# create a tcp server socket as s
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
	# bind the socket to the local ip address
	s.bind((HOST, PORT))
	# listen for incoming connections from the client
	s.listen(5)
	print(f"[+] Listening as {HOST}:{PORT}")
	# print the address of the connected client
	print(f"[+] {address} is connected")
	# receive the filename and file size from the client
	while True:
		# we keep listening for new connections all the time
		client_socket, client_address = s.accept()
		print(f"[+] {client_address} connected.")
		# add the new connected client to connected sockets
		client_sockets.add(client_socket)
		# start a new thread that listens for each client's messages
		t = Thread(target=listen_for_client, args=(client_socket,))
		# make the thread daemon so it ends whenever the main thread ends
		t.daemon = True
		# start the thread
		t.start()